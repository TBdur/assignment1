**Licensing:**
This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License. 
To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ 
or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA. 


**Details Of Original Sketch:** 
Original sketch from openprocessing.org 
By user 'skizzm', 2nd November 2017 
User profile: 
https://www.openprocessing.org/user/105743 
Original Sketch: 
https://www.openprocessing.org/sketch/469866 

Originally licensed under Creative Commons, 
Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0) 
https://creativecommons.org/licenses/by-sa/3.0/ 
